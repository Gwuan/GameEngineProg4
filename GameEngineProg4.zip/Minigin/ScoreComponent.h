#pragma once
#include "Component.h"
class ScoreComponent :
    public Component
{
};

